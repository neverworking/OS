Place mp3 files here and update src/App.jsx playlist entries to point to /assets/audio/yourfile.mp3
